﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* point options (desc)
3  : lvl 1 mob
5  : +1 stat
7  : lvl 2 mob
10 : +2 stat
12 : lvl 3 mob
15 : +3 stat
18 : lvl 4 mob
30 : lvl 5 mob
*/

public class MobSpawner : MonoBehaviour {
	public GameObject DiaEnemyPrefab;
	public Material[] DiaMaterials;

	List<KeyValuePair<int, string>> options = new List<KeyValuePair<int, string>> (){
		new KeyValuePair<int, string> (3, "lvl1mob"), 
		new KeyValuePair<int, string> (5, "+1stat"), 
		new KeyValuePair<int, string> (7, "lvl2mob"),
		new KeyValuePair<int, string> (10,"+2stat"),
		new KeyValuePair<int, string> (12,"lvl3mob"),
		new KeyValuePair<int, string> (15,"+3stat"),
		new KeyValuePair<int, string> (18,"lvl4mob"),
		new KeyValuePair<int, string> (30,"lvl5mob"),

	};
		
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void createStack(int levelPointsValue, int taskNumber, int bossNumber){
		// task is a number of enemies to overcome
		List<int> enemyValueArray = new List<int>(); //each value array is points assigned for each task (first task player encounters to last)
		for (int i = 1; i <= taskNumber; i++) {
			enemyValueArray [i - 1] = 10 * i; //each task gets 10 points multiplied by the stage in the game (early enemies are easyer)
		}
		//generate stack of mobs from points value
		//rules:
		//if 'boss' inlcuded must have a boss mob
		//number of mobs must be AT LEAST min of enemy obstacle positions
		if (bossNumber != 0){ //0 = no boss
			if (enemyValueArray[bossNumber] < 30){
				enemyValueArray [bossNumber] = 30; //give task number at least 30 points so it can spawn a boss (boss is 30 points min to spawn)
			}
		}

		//now generate mobs for each task
		foreach (int mobPoints in enemyValueArray){
			int currPointsLeft = mobPoints;
			do {
				//create new options list to be filtered down
				List<KeyValuePair<int, string>> possibleOptions = options;
				int points = Random.Range(1, currPointsLeft);

				//filter choices for points chosen (remove too expensive options)
				for (int i = 0; i < options.Count; i++){
					if (options[i].Key > points){
						possibleOptions.RemoveAt(i);
					}
				}


			} while(currPointsLeft > 0);
		}
	}

	public void spawnMob(){

	}
}
	
