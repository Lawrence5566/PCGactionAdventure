﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimatorHook : MonoBehaviour {

	Animator anim;
	InputHandler inputHan;

	public float rm_multi; //root motion multiplier

	public void Init(InputHandler i){
		inputHan = i;
		anim = i.anim;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnAnimatorMove(){
		if (inputHan.canMove){
			return;
		}

		inputHan.rigid.drag = 0; //set drag to zero since we are using root motion

		if (rm_multi == 0)
			rm_multi = 1;

		Vector3 delta = anim.deltaPosition;
		delta.y = 0;
		Vector3 v = (delta * rm_multi) / Time.deltaTime;
		inputHan.rigid.velocity = v;
	}
}
