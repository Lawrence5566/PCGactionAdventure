﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {
	public int level;
	public int hp;
	public int physicalStr;
	public int magicalStr;
	public int physicalDef;
	public int magicalDef;

}
