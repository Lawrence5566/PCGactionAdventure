﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

//need to clear up/remove/merge connections, connected nodes and connectednodeforgraph

public class GraphGenerator : MonoBehaviour {
	public GameObject TextBasePrefab;
	public Sprite circle;
	public Sprite connectionSpr;
	public Sprite connectionArrowSpr;
	node[] nodeArray = new node[12];
	node startNode;
		
	void Start () { //using awake as got recursion in... (never use recursion in start)

		int n = 0;
		for (int x = 0; x < 3; x++) { //3 across and 4 down node array - starts bottom left in world, goes up
			for (int y = 0; y < 4; y++) {
				nodeArray[n] = new node(this.transform.position + new Vector3 (x * 4f, y * 4f, 0f), "node" + n, circle); //space nodes out 3.5 units apart
				n ++;
			}
		}

		n = 0;
		for (int x = 0; x < 3; x++) { //creating starting connections and setting adjacent nodes
			for (int y = 0; y < 4; y++) {
				for (int i = 0; i < nodeArray.Length; i++) { //for each node in array
					var relativePoint = nodeArray[n].obj.transform.InverseTransformPoint(nodeArray[i].obj.transform.position);

					if (relativePoint.x == -4.0 && relativePoint.y == 0) { //has left node (and not above or below)
						nodeArray[n].connections[0] = new connection(nodeArray[n].position + new Vector3(-2f,0f,0f), connectionSpr, 90f); //add left
						nodeArray[n].connectedNodes.Add(nodeArray[i]);
					}
					if (relativePoint.x == 4.0 && relativePoint.y == 0) { //has right node
						nodeArray[n].connections[2] = new connection(nodeArray[n].position + new Vector3(2f,0f,0f), connectionSpr, 90f); //right
						nodeArray[n].connectedNodes.Add(nodeArray[i]);
					}
					if (relativePoint.y == 4.0 && relativePoint.x == 0) { //has top node (and not right or left)
						nodeArray[n].connections[1] = new connection(nodeArray[n].position + new Vector3(0f,2f,0f), connectionSpr, 0f); //top
						nodeArray[n].connectedNodes.Add(nodeArray[i]);
					}
					if (relativePoint.y == -4.0 && relativePoint.x == 0) { //has bot node
						nodeArray[n].connections[3] = new connection(nodeArray[n].position + new Vector3(0f,-2f,0f), connectionSpr, 0f); //bot
						nodeArray[n].connectedNodes.Add(nodeArray[i]);
					}
				}
				n++;
			}
		}

		//create dungeon:
		DungeonRule();

		//pass on to map converter:
		int[,] map = FindObjectOfType<GraphToMapConverter>().CreateMap(nodeArray);
		//generate mesh:
		FindObjectOfType<MeshGenerator>().GenerateMesh(map,1); //squareSize of 1

	}

	public List<node> findAPath(node curr, List<node> visited, List<node> p){ //recursivly finds a path to goal
		List<node> path = p;
		visited.Add (curr); //mark current node as visited
		path.Add(curr); 	//add to path

		if (curr.obj.name == "GoalNode") {
			return path; //return path
		} else{ //not at destination
			//recurse for next random node
			//List<node> validNodes = curr.connectedNodes; //this does not work, if you delete from valid nodes, you delete from connectedNodes as this is a reference
			List<node>  validNodes = new List<node> (curr.connectedNodes); //use this instead
			node newNode;

			for (int i = 0; i < 4; i++) { //4 = max number of adjacent nodes

				int index = Random.Range(0, validNodes.Count); 			//pick a node
				newNode = validNodes [index]; 								//set node

				if (!visited.Contains (newNode) && newNode != null) { 		//check if node is valid
					path = findAPath(newNode, visited, path);				//recurse to extend the path
					break; 													//break, we have what we came for!
				} else{
					validNodes.Remove(newNode); 							//remove from valid nodes
				}
					
				if(validNodes.Count == 0){ 									//if no nodes are valid, we got trapped in a corner
					path.Remove(curr);										//remove current node from path, but keep as visited so its ignored
					newNode = path[path.Count - 1];							//set next node to look at to be the previous node (which is currently at the end)
					path.Remove(newNode); 									//remove the new node(previous) from path, so it isn't added again by accident - !important to stop infinte recursion
					visited.Remove(newNode); 								//remove the new node from path, same reason ^^
					path = findAPath(newNode, visited, path);				//recurse to go back to previous node
					break; //to stop the max 4 loops
				}
			}
		}
		return path;
	}

	public void addConnection(node a, node b){
		//determine position of node a from node b and vise versa
		//add to each others 'connectedNodes' by position
		//set corresponding 'connections' arrow in object (remove old one) to new arrow from a -> b since thats how this should be called (start to finish)

		var relativePoint = a.obj.transform.InverseTransformPoint(b.obj.transform.position);

		if (relativePoint.x == -4.0) { //b is to the left (0)
			connection connectionOld = a.connections[0];
			a.connections[0] = new connection(connectionOld.position, connectionArrowSpr, 270f); 					//add new connection arrow from a -> b, left
			Destroy(connectionOld.obj); 																			//destroy old connection
		}
		if (relativePoint.x == 4.0) { //right (2)
			connection connectionOld = a.connections[2];
			a.connections[2] = new connection(connectionOld.position, connectionArrowSpr, 90f); 
			Destroy(connectionOld.obj); 
		}
		if (relativePoint.y == 4.0) { //above (1)
			connection connectionOld = a.connections[1];
			a.connections[1] = new connection(connectionOld.position, connectionArrowSpr, 180f); 
			Destroy(connectionOld.obj); 
		}
		if (relativePoint.y == -4.0) { //below (3)
			connection connectionOld = a.connections[3];
			a.connections[3] = new connection(connectionOld.position, connectionArrowSpr, 0f); 
			Destroy(connectionOld.obj); 
		}

		if (!a.connectedNodes.Contains (b)) {
			a.connectedNodes.Add (b); //make nodes adjacent, if they were not already
		}
		if (!b.connectedNodes.Contains (a)) {
			b.connectedNodes.Add(a);
		}
	}


	// graph grammer functions: 

	//Dungeon > Rooms + Goal
	public void DungeonRule(){
		//set start symbol - picks random location
		startNode = nodeArray[Random.Range(0,11)];
		GameObject text = Instantiate(TextBasePrefab,  startNode.obj.transform);
		startNode.obj.name = "StartNode";
		text.GetComponent<TextMesh>().text = "Start";

		//fire 'goal' function
		GoalRule();
		//fire 'rooms'
		RoomsRule ();
		
	}

	public void GoalRule(){
		//create goal location
		GameObject goalNode;
		do { //keep picking different spots till you get one that isnt the start node
			goalNode = nodeArray [Random.Range (0, 11)].obj;
		} while (goalNode.name == "StartNode");
		GameObject text = Instantiate(TextBasePrefab,  goalNode.transform);
		goalNode.name = "GoalNode";
		text.GetComponent<TextMesh>().text = "Goal";

		//generate 2 paths between them
		//find a path between start and goal:
		List<node> routeA = new List<node>();
		List<node> routeB = new List<node>();

		do { //make sure paths are different
			routeA = findAPath (startNode, new List<node> (), new List<node> ());
			routeB = findAPath (startNode, new List<node> (), new List<node> ());
		} while (Enumerable.SequenceEqual(routeA, routeB));

		string s1 = "";
		string s2 = "";
		foreach (node n in routeA) {
			s1 += (n.name + ", ");
		}
		foreach (node n in routeB) {
			s2 += (n.name + ", ");
		}
		Debug.Log("path1: " + s1);
		Debug.Log("path2: " + s2);

		//destory all connections
		for(int i = 0; i < nodeArray.Length; i++){
			nodeArray [i].connectedNodes.Clear();
			for (int j = 0; j < 4; j++){
				if (nodeArray [i].connections [j] != null) {
					Destroy (nodeArray [i].connections [j].obj);
				}
			}
		}	

		//re-add connections for only paths
		for (int i = 1; i < routeA.Count; i++){ //start from one ahead, so that we don't go out of range
			addConnection (routeA [i - 1], routeA [i]);
		}
		for (int i = 1; i < routeB.Count; i++){ 
			addConnection (routeB [i - 1], routeB [i]);
		}

		//decide goal (for this game its just a boss + item)
		//create boss token, create item token

	}

	public void RoomsRule(){
		
	}



}

//utlilty classes used for this generator and other parts of the project

public class node{
	public Vector3 position;
	public string name;
	public connection[] connections = new connection[4]; //array of 4 connections: left, top, right, bot
	public GameObject obj;
	public List<node> connectedNodes = new List<node>();

	public node(Vector3 pos, string n, Sprite i){
		position = pos;
		name = n;

		//create node in world
		obj = new GameObject(name);		
		obj.transform.position = position;
		SpriteRenderer ren = obj.AddComponent<SpriteRenderer>();	
		ren.sprite = i;

	}
}

public class connection{ //may not need
	public Vector3 position;
	public GameObject obj;

	public connection(Vector3 pos, Sprite i, float rot){
		position = pos;

		//create connection in world
		obj = new GameObject("connection");	
		obj.transform.position = position;
		obj.transform.Rotate(new Vector3(0f,0f,rot));
		SpriteRenderer ren = obj.AddComponent<SpriteRenderer>();	
		ren.sprite = i;
	}
}
